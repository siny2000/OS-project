/* Developers
  Thanyaporn Ngamsangeim 6210742182
  Suthasinee Wongsricha 6210742182
 */

import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.Random;
import javax.swing.Timer;
import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;


public class HitMeIfYouCan extends GraphicsProgram{
	
	private static final int WINDOW_WIDTH = 800, WINDOW_HEIGHT = 600;	
	private static int DELAY = 9;
	private static final double INITIAL_VY = 3;
	private static final double INITIAL_VX = 3;
	private static final int BALL_RADIUS = 15;
	private static final int PADDLE_WIDTH = 120, PADDLE_HEIGHT = 20;
	private static final int BRICK_SIZE = 90;
	
	private boolean play = false;
	private boolean start = false;
	private RandomGenerator rg = new RandomGenerator();
	private GRect paddle = null;
	private GRect brick = null;
	private GImage img = null;
	private GOval ball = null;
	private int score = 0;
	private double checkPadX,checkPadY;

	public void run() {	
		
		double vx = INITIAL_VX;
		double vy = -INITIAL_VY;
		setWidth(WINDOW_WIDTH);
		setHeight(WINDOW_HEIGHT);		
		
		//create anything
		Random rand = new Random();
		background();
		paddle = makeRect(PADDLE_WIDTH, PADDLE_HEIGHT , WINDOW_WIDTH/2 - PADDLE_WIDTH/2,WINDOW_HEIGHT * 9/10 );
		brick = makeRect(BRICK_SIZE,BRICK_SIZE,rand.nextInt(WINDOW_WIDTH - BRICK_SIZE),rand.nextInt(WINDOW_HEIGHT * 9/10 - BRICK_SIZE * 2));
		ball = makeBall();
		startPage();
		
		//play loop
		while(true) {
			if(hitLeftWall(ball) || hitRightWall(ball)) {
				vx = -vx;
			}
			
			if(hitTopWall(ball)) {
				vy = -vy;
			}
				
			if(hitBrickLeft(ball) || hitBrickRight(ball) || hitBrickTop(ball) || hitBrickBottom(ball)) {
				score++;	
				remove(brick);
				if(DELAY > 3)
					DELAY--;
				brick = makeRect(BRICK_SIZE,BRICK_SIZE,rand.nextInt(WINDOW_WIDTH - BRICK_SIZE),rand.nextInt(WINDOW_HEIGHT * 9/10 - BRICK_SIZE));
				
				if(hitBrickLeft(ball) || hitBrickRight(ball))
					vx = -vx;
				else
					vy = -vy;
			}
			
			if(hitPad(ball)) {
				vy = -vy;
				if(checkPadX <= paddle.getX() + PADDLE_WIDTH/2)
					if(checkPadX > WINDOW_WIDTH)
						vx = -vx;
				else if(checkPadX >	paddle.getX() + PADDLE_WIDTH/2){
					if(checkPadX < WINDOW_WIDTH)
						vx = -vx;
				}
			}
			
			if(hitBottomWall(ball)) {
				break;
			}
			if(play)
				ball.move(vx, vy);
			pause(DELAY);
		}
		
		//game over
		remove(brick);
		remove(ball);
		remove(paddle);
		endPage();
		gameOver();
	
	}
	
	//create start page
	private void startPage() {
		img = image("startPage.jpg");
	}
	
	//create background
	private void background() {
		img = image("bg1.jpg");

	}
	
	//create end page
	private void endPage() {
		img = image("endPage.jpg");		
	}

	
	//add background in start page
	private GImage image(String s) {
		GImage bg = new GImage(s);
		add(bg,0,0);
		return bg;
	}
	
	
	//check mouse clicked to start the game
	public void mouseClicked(MouseEvent e) {
		int clickX = e.getX();
		int clickY = e.getY();
		if((clickX >= 330 && clickX <= 505) && (clickY >= 415 && clickY <= 475 && !start)) {
			remove(img);
			play = true;
			start = true;
		}
	}
	
	//make ball object
	private GOval makeBall() {
		double size = BALL_RADIUS * 2;
		GOval r = new GOval(size, size);
		r.setFilled(true);
		r.setColor(rg.nextColor());
		add(r, WINDOW_WIDTH/2 - BALL_RADIUS, WINDOW_HEIGHT * 9/10 - size - 1);
		return r;
	}
	
	//make rect object
	private GRect makeRect(int w, int h, int x, int y ) {
		GRect b = new GRect(w, h);
		b.setFilled(true);
		b.setColor(rg.nextColor());
		add(b, x, y);
		return b;
		
	}
	
	//paddle movement
	public void mouseMoved(MouseEvent e) {
		//start = true;
		GRect b = new GRect(150, 15);
		b.setFilled(true);
		b.setColor(Color.green);
		if(e.getX() < getWidth() - 150)
			paddle.setLocation(e.getX(),WINDOW_HEIGHT*9/10);
		else 
			paddle.setLocation(WINDOW_WIDTH - PADDLE_WIDTH,WINDOW_HEIGHT*9/10);
		
	}
	
	// end page
	private void gameOver() {
		Label l1;  
	    l1=new Label(Integer.toString(score));  
	    Font myFont = new Font("Serif", Font.CENTER_BASELINE, 50);
	    l1.setFont(myFont);
	    l1.setForeground(Color.pink);
	    add(l1,478,315); 
	    l1.setVisible(true);    
	}
	
	
	// check if ball hit paddle
	private boolean hitPad(GOval b) {
		checkPadX = b.getX() + b.getWidth();
		checkPadY = b.getY() + b.getHeight();
		
		GObject collidingObject = getElementAt(checkPadX, checkPadY);
		
		return collidingObject == paddle;	
	}
	
	// check if ball hit left side of brick
	private boolean hitBrickLeft(GOval b) {
		double checkX = b.getX();
		double checkY = b.getY();
		
		GObject collidingObjectLeft = getElementAt(checkX + b.getWidth() , checkY + BALL_RADIUS);
		
		return collidingObjectLeft == brick;
	
	}
	
	// check if ball hit right side of brick
	private boolean hitBrickRight(GOval b) {
		double checkX = b.getX();
		double checkY = b.getY();
		GObject collidingObjectRight = getElementAt(checkX , checkY + BALL_RADIUS);		
		return collidingObjectRight == brick;
		
	}
		
		// check if ball hit top side of brick
	private boolean hitBrickTop(GOval b) {
		double checkX = b.getX();
		double checkY = b.getY();
		GObject collidingObjectTop = getElementAt(checkX + BALL_RADIUS, checkY + + b.getHeight());
		return collidingObjectTop == brick;
		
	}
		
	// check if ball hit bottom side of brick
	private boolean hitBrickBottom(GOval b) {
		double checkX = b.getX();
		double checkY = b.getY();
		GObject collidingObjectBottom = getElementAt(checkX + BALL_RADIUS , checkY);		
		return collidingObjectBottom == brick;
		
	}
	
	//check if ball hit bottom wall
	private boolean hitBottomWall(GOval b) {
		return b.getY() > getHeight() - b.getHeight();
	}
	
	//check if ball hit top wall
	private boolean hitTopWall(GOval b) {
		return b.getY() <= 0;
	}

	//check if ball hit right wall
	private boolean hitRightWall(GOval b) {
		return b.getX() >= getWidth() - b.getWidth();
	}
	//check if ball hit left wall
	private boolean hitLeftWall(GOval b) {
		return b.getX() <= 0;
	}
	
}

